package com.example.pharmaExpress;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PharmaExpressApplicationTests {

	@Test
	void contextLoads() {
	}

}
