package com.example.pharmaExpress;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PharmaExpressApplication {

	public static void main(String[] args) {
		SpringApplication.run(PharmaExpressApplication.class, args);
	}

}
