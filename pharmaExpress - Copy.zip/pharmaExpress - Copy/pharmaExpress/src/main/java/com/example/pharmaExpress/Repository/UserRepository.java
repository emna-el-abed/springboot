package com.example.pharmaExpress.Repository;
import com.example.pharmaExpress.Entity.User;

import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
    // You can define custom queries if necessary
}

